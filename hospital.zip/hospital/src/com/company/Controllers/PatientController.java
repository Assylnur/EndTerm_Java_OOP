package com.company.Controllers;

import com.company.DB.DatabaseConnection;
import com.company.Entity.Patient;
import com.company.Interface.PatientInterface;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class PatientController implements PatientInterface {
    @Override
    public void register(Patient patient) {
        String name = patient.getName();
        int age = patient.getAge();
        String password = patient.getPassword();
        try {
            Connection connection = DatabaseConnection.getInstance().getConnection();
            String sql = "INSERT INTO users (name, age, password) VALUES(?, ?, ?);";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, name);
            preparedStatement.setInt(2, age);
            preparedStatement.setString(3, password);
            int rows = preparedStatement.executeUpdate();

            System.out.printf("%d rows added", rows);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    @Override
    public boolean login(String name, String password) {
        boolean flag = false;
        try{
            Connection connection = DatabaseConnection.getInstance().getConnection();
            Statement st = connection.createStatement();
            ResultSet resultSet = st.executeQuery("SELECT name, password FROM users");
            while (resultSet.next()){
                if (name.equals(resultSet.getString("name"))){
                    if(password.equals(resultSet.getString("password"))){
                        flag = true;
                    }else {
                        flag = false;
                        System.out.println("Wrong username or password");
                    }
                }else {
                    flag = false;
                    System.out.println("No such user in the database");
                }
            }
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
        return flag;
    }

    @Override
    public void chooseDoctor(int doctorId, int userId) {
        try {
            Connection connection = DatabaseConnection.getInstance().getConnection();
            String sql = "INSERT INTO appointments (userId, doctorId) VALUES(?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1, userId);
            preparedStatement.setInt(2, doctorId);
            int rows = preparedStatement.executeUpdate();

            System.out.printf("%d rows added", rows);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    @Override
    public void showMyDoctor(int userId) {
        try {
            Connection connection = DatabaseConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement("Select doctor.name\n" +
                    "  from users\n" +
                    "  inner join appointments\n" +
                    "    on users.id=appointments.userId\n" +
                    "    inner join doctor\n" +
                    "    on doctor.id=appointments.doctorId\n" +
                    "    where users.id=?;");

            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()){
                String name = rs.getString("name");
                System.out.printf("%s", name);
                System.out.println();
            }
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    @Override
    public Integer getId(String name) {
        try {
            Connection connection = DatabaseConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement("SELECT id FROM users WHERE name = ?");
            ps.setString(1, name);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                return rs.getInt("id");
            }
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
        return null;
    }
}
