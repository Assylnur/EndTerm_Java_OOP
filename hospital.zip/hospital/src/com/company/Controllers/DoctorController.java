package com.company.Controllers;

import com.company.DB.DatabaseConnection;
import com.company.Interface.DoctorInterface;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class DoctorController implements DoctorInterface {
    @Override
    public boolean login(String name, String password) {
        boolean flag = false;
        try{
            Connection connection = DatabaseConnection.getInstance().getConnection();
            Statement st = connection.createStatement();
            ResultSet resultSet = st.executeQuery("SELECT name, password FROM doctor");
            while (resultSet.next()){
                if (name.equals(resultSet.getString("name"))){
                    if(password.equals(resultSet.getString("password"))){
                        flag = true;
                    }else {
                        flag = false;
                        System.out.println("Wrong username or password");
                    }
                }
            }
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
        return flag;
    }

    @Override
    public Integer showMySalary(int myId) {
        try {
            Connection connection = DatabaseConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement("SELECT salary FROM doctor WHERE id = ?");
            ps.setInt(1, myId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()){
                return rs.getInt("salary");
            }
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
        return null;
    }

    @Override
    public void showMyPatients(int myId) {
        try {
            Connection connection = DatabaseConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement("Select  users.name\n" +
                    "  From doctor\n" +
                    "  inner join appointments\n" +
                    "  on doctor.id=appointments.doctorId\n" +
                    "  inner join users\n" +
                    "  on users.id=appointments.userId\n" +
                    "  where doctor.id=?;");
            ps.setInt(1, myId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()){
                String name = rs.getString("name");
                System.out.printf("%s", name);
                System.out.println();
            }
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    @Override
    public String showSpeciality(int myId) {
        try {
            Connection connection = DatabaseConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement("SELECT speciality FROM doctor WHERE id = ?");
            ps.setInt(1, myId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()){
                return rs.getString("speciality");
            }
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
        return null;
    }
}
