package com.company.Entity;

public class Doctor {
    private String name;
    private int salary;
    private String speciality;
    private String password;


    public Doctor(String name, int salary, String speciality, String password) {
        this.name = name;
        this.salary = salary;
        this.speciality = speciality;
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getSalary() {
        return salary;
    }

    public void setSalary(int salary) {
        this.salary = salary;
    }

    public String getSpeciality() {
        return speciality;
    }

    public void setSpeciality(String speciality) {
        this.speciality = speciality;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
