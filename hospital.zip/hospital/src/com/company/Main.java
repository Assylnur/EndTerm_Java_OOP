package com.company;

import com.company.Controllers.DoctorController;
import com.company.Controllers.PatientController;
import com.company.Entity.Patient;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        System.out.println("Welcome!");
        Scanner sc = new Scanner(System.in);
        System.out.println("Please choose Doctor(1) OR Patient(2) ");
        int choice = sc.nextInt();
        try {
            if (choice == 1){
                System.out.println("Please write your name: ");
                String name = sc.next();
                System.out.println("Please write your password: ");
                String password = sc.next();
                DoctorController doctorController = new DoctorController();
                if(doctorController.login(name, password)){
                    System.out.println("Please choose one of these options: 1 - show salary. 2 - description speciality. 3 - show patients");
                    int option = sc.nextInt();
                    System.out.println("Please, specify your ID: ");
                    int id = sc.nextInt();
                    if (option == 1){
                        System.out.println(doctorController.showMySalary(id));
                    }else if (option == 2){
                        System.out.println("You are: " + doctorController.showSpeciality(id));
                    }else if(option == 3){
                        doctorController.showMyPatients(id);
                    }
                }
            }else if(choice == 2){
                System.out.println("Choose some options: 1 - Registration. 2 - Login");
                int option = sc.nextInt();
                if(option == 1){
                    System.out.println("Please, write your name: ");
                    String name = sc.next();
                    System.out.println("Please, write your age: ");
                    int age = sc.nextInt();
                    System.out.println("Please, write your password: ");
                    String password = sc.next();
                    Patient patient = new Patient(name, age, password);
                    PatientController patientController = new PatientController();
                    patientController.register(patient);
                }else if(option == 2){
                    System.out.println("Please write your name: ");
                    String name = sc.next();
                    System.out.println("Please write your password: ");
                    String password = sc.next();
                    PatientController patientController = new PatientController();
                    if(patientController.login(name, password)){
                        System.out.println("Welcome to the system!");
                        System.out.println("Please, select one of the options: Choose doctor - 1, Show my doctor - 2 ");
                        int x = sc.nextInt();
                        int y = 0;
                        int userId = patientController.getId(name);
                        if(x == 1){
                            DoctorController doctorController = new DoctorController();
                            System.out.println("");
                             y = sc.nextInt();
                            patientController.chooseDoctor(y, userId);
                        }else if (x == 2){
                            patientController.showMyDoctor(userId);
                        }
                    }
                }
            }
        }catch (InputMismatchException e){
            System.out.println(e.getMessage());
        }
    }
}
