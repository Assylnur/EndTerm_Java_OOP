package com.company.Interface;

import com.company.Entity.Patient;

public interface PatientInterface {
    public void register(Patient patient);
    public boolean login(String name, String password);
    public void chooseDoctor(int doctorId, int userId);
    public void showMyDoctor(int doctorId);
    public Integer getId(String name);
}
