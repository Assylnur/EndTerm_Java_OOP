package com.company.Interface;

public interface DoctorInterface {
    public boolean login (String name, String password);
    public Integer showMySalary(int myId);
    public void showMyPatients(int myId);
    public String showSpeciality(int myId);
}
